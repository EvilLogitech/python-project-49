### Hexlet tests and linter status:
[![Actions Status](https://github.com/EvilLogitech/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EvilLogitech/python-project-49/actions)
# Asciinema record
https://asciinema.org/a/EKt4WdgohjKaaGXBpR0yj9tfR