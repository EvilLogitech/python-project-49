# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:play_game',
                     'brain-even = brain_games.scripts.brain_even:play_game',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:play_game',
                     'brain-prime = brain_games.scripts.brain_prime:play_game',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:play_game']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'First project Schvp',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/EvilLogitech/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EvilLogitech/python-project-49/actions)\n# Asciinema record\n# game even\nhttps://asciinema.org/a/EKt4WdgohjKaaGXBpR0yj9tfR\n# game calc\nhttps://asciinema.org/a/OIOTRSGcrBto0ymalaluW0jS3\n# game gcd\nhttps://asciinema.org/a/6yxQ0cFjnM6mGoc9YAyn3G5OR\n# game progression\nhttps://asciinema.org/a/zThE0Ldt5sw0s3HWzM6RIY08M',
    'author': 'Viktor Shcherbakov',
    'author_email': 'evil.logitech@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
